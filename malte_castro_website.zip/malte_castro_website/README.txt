MALTE CASTRO WEBSITE — QUICK START
===================================

This is a free, responsive five-tab website for Malte Castro:
1. Portfolio
2. Video
3. Music
4. About
5. Contact

CONTACT
The email link is already set to maltenc@hotmail.dk.

PREVIEW THE WEBSITE
1. Unzip this folder.
2. Double-click index.html to open it in your browser.
3. You can edit index.html with a free text editor such as Visual Studio Code or Notepad.

HOW TO ADD YOUR CONTENT
Open index.html and search for the placeholder you want to replace.

PORTFOLIO PHOTOS
- Put image files in images/portfolio/.
- In the portfolio section, replace a placeholder <div class="placeholder">...</div>
  with an image tag, for example:
  <img src="images/portfolio/your-photo.jpg" alt="Malte Castro portrait">
- Copy a tile block to add more photos.

VIDEOS
- Recommended: upload videos to YouTube or Vimeo (both have free options), then copy the
  video's Embed code and replace a video placeholder with that embed code.
- Example:
  <iframe width="100%" height="100%" src="https://www.youtube-nocookie.com/embed/VIDEO_ID"
    title="Malte Castro showreel" frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
    allowfullscreen></iframe>
- Self-hosted video files can be added using a <video controls src="videos/your-video.mp4"></video>
  tag, but large video files can make the site slow and may exceed free hosting limits.

MUSIC / SPOTIFY
- Replace https://open.spotify.com/ with Malte's exact Spotify artist or release URL.
- Put cover images in images/music/.
- Replace each cover placeholder with:
  <img src="images/music/cover-name.jpg" alt="Release title cover">
- Update each release title, year, and link. Copy an <article class="album">...</article>
  block for every single, EP, or album.

BIO
- Find the "About Malte Castro" section and replace the sample paragraphs with the real bio.

PUBLISH FOR FREE — NO DOMAIN NEEDED
Option A: GitHub Pages (free)
1. Create a free account at https://github.com/
2. Create a new public repository, e.g. malte-castro-website.
3. Upload all files and folders from this website folder (especially index.html).
4. In the repository, open Settings → Pages.
5. Choose deploy from the main branch and the root folder, then Save.
6. GitHub will provide a free address similar to https://YOUR-USERNAME.github.io/malte-castro-website/
   (the exact address depends on your GitHub username and repository name).

Option B: Netlify (free plan availability/limits may change)
1. Create a free account at https://www.netlify.com/
2. Use its manual deploy / drag-and-drop publishing option and upload the website folder.
3. Netlify gives you a free subdomain. No custom domain is required.

IMPORTANT LIMITATION
This is a static website, so visitors cannot upload content to the live site through the tabs.
To update the live site, you edit index.html and upload/deploy the changed files again.
No paid hosting, paid domain, database, or subscription is required for the basic site.
